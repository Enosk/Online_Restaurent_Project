package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Serv
 */
@WebServlet("/Serv")
public class Serv extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Serv() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
        String uname = request.getParameter("t1");
        String password = request.getParameter("t2"); // Password as String

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ttproject", "root", "tiger");

           // String insertQuery = "INSERT INTO ttlogin VALUES (?, ?)";
            PreparedStatement ps=con.prepareStatement("select * from ttlogin where uname=? AND password=?");
			ps.setString(1,uname);
			ps.setString(2, password);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				response.sendRedirect("f.html");
			}
			else
			{
				response.sendRedirect("h.html");
			}
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exception properly, maybe redirect to an error page
        }
	}

}
