package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Signupservlet
 */
@WebServlet("/Signupservlet")   
public class Signupservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Signupservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#service(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		PrintWriter pw = response.getWriter();
        String uname = request.getParameter("t1");
        String password = request.getParameter("t2");
        String item_name=request.getParameter("t3");
        // Password as String

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/ttproject", "root", "tiger");

           // String insertQuery = "INSERT INTO ttlogin VALUES (?, ?)";
            PreparedStatement ps=con.prepareStatement("DELETE FROM ttlogin WHERE uname=? AND password=?");
			ps.setString(1,uname);
			ps.setString(2, password);
			
			 PreparedStatement ps1=con.prepareStatement("DELETE FROM orders WHERE item_name=?");
			 ps1.setString(1,item_name);
			 ps1.executeUpdate();
			 ;
			 int rowsDeleted = ps.executeUpdate();
			 
			 
			 
	            if (rowsDeleted > 0) {
	                response.sendRedirect("l.html"); // Redirect if record deleted
	            } else {
	                // Redirect to some page indicating failure
	                response.sendRedirect("error.html");
	            }
			
        } catch (Exception e) {
            e.printStackTrace();
            // Handle exception properly, maybe redirect to an error page
        }
	}

}
